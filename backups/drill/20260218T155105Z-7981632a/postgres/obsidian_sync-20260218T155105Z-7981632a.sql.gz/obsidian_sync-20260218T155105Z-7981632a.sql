--
-- PostgreSQL database dump
--

\restrict De47muokqT6ekrbE0E3rxoo0qFQQNpFxiP5kNZLQlc3dqWI2kRE3GN86JLquPsn

-- Dumped from database version 16.12
-- Dumped by pg_dump version 16.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: change_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.change_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vault_id uuid NOT NULL,
    changeset_id uuid NOT NULL,
    checkpoint bigint NOT NULL,
    op text NOT NULL,
    file_id uuid NOT NULL,
    path text NOT NULL,
    version integer NOT NULL,
    content_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT change_events_op_check CHECK ((op = ANY (ARRAY['create'::text, 'update'::text, 'delete'::text, 'rename'::text, 'move'::text])))
);


ALTER TABLE public.change_events OWNER TO postgres;

--
-- Name: changesets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.changesets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vault_id uuid NOT NULL,
    device_id uuid NOT NULL,
    checkpoint bigint NOT NULL,
    status text DEFAULT 'committed'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.changesets OWNER TO postgres;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    device_name text NOT NULL,
    platform text NOT NULL,
    plugin_version text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT devices_platform_check CHECK ((platform = ANY (ARRAY['macos'::text, 'windows'::text, 'android'::text, 'ios'::text, 'linux'::text, 'unknown'::text]))),
    CONSTRAINT devices_status_check CHECK ((status = ANY (ARRAY['active'::text, 'revoked'::text])))
);


ALTER TABLE public.devices OWNER TO postgres;

--
-- Name: file_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vault_id uuid NOT NULL,
    current_path text NOT NULL,
    head_version integer DEFAULT 0 NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.file_entries OWNER TO postgres;

--
-- Name: file_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    file_id uuid NOT NULL,
    version integer NOT NULL,
    content_hash text NOT NULL,
    author_device_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.file_versions OWNER TO postgres;

--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.idempotency_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vault_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    response_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.idempotency_keys OWNER TO postgres;

--
-- Name: object_blobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.object_blobs (
    content_hash text NOT NULL,
    size_bytes bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.object_blobs OWNER TO postgres;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    device_id uuid NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


ALTER TABLE public.refresh_tokens OWNER TO postgres;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_migrations (
    id text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: sync_prepares; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sync_prepares (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vault_id uuid NOT NULL,
    device_id uuid NOT NULL,
    base_checkpoint bigint NOT NULL,
    changes_json jsonb NOT NULL,
    conflicts_json jsonb NOT NULL,
    status text DEFAULT 'prepared'::text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sync_prepares_status_check CHECK ((status = ANY (ARRAY['prepared'::text, 'conflicted'::text, 'committed'::text, 'expired'::text])))
);


ALTER TABLE public.sync_prepares OWNER TO postgres;

--
-- Name: tombstones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tombstones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vault_id uuid NOT NULL,
    file_id uuid NOT NULL,
    deleted_at timestamp with time zone DEFAULT now() NOT NULL,
    expire_at timestamp with time zone NOT NULL
);


ALTER TABLE public.tombstones OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: vault_sync_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vault_sync_state (
    vault_id uuid NOT NULL,
    latest_checkpoint bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.vault_sync_state OWNER TO postgres;

--
-- Name: vaults; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vaults (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_user_id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.vaults OWNER TO postgres;

--
-- Data for Name: change_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.change_events (id, vault_id, changeset_id, checkpoint, op, file_id, path, version, content_hash, created_at) FROM stdin;
d353b7e0-9168-4c8d-aee1-501cdb648203	92fe0015-2cb8-43f6-b836-a5d982ae692f	f9f02d5d-d314-4fea-b842-e8645e90a2df	1	create	61c09010-627a-4b5b-a0a2-dea0f6ef678b	notes/smoke.md	1	sha256:smoke-1771420995186	2026-02-18 13:23:15.358933+00
ee91afd9-524c-44e5-8fd6-0ac5ff828994	7f62237f-1b4c-4008-84d3-241ee11a25fc	f314a855-e81a-4d3f-93e2-2536dc4ed49b	1	create	28c4158e-3f21-444d-a916-0918f424a44b	notes/smoke.md	1	sha256:smoke-1771421149698	2026-02-18 13:25:49.873056+00
698ca9a6-ec5e-4fe6-8f4a-0542d3ac2187	3d84e540-449f-4818-933e-635f024a8cea	cf1d7d63-d365-4c35-a547-36f927454d5f	1	create	be5f4339-314d-4d71-9231-42cd931bf920	notes/smoke.md	1	sha256:smoke-1771421564345	2026-02-18 13:32:44.506913+00
d3566112-2618-450d-9a05-38311f936e7e	bf005287-dca4-4685-8ac2-22185865980d	9bb165de-a270-4e4e-b7ac-66e797230bd4	1	create	0f8c2008-5fba-4866-8a2f-49670d4d47b3	notes/smoke.md	1	sha256:smoke-1771422871028	2026-02-18 13:54:31.202399+00
3d574857-2648-4e2d-b0e1-9c8b824cb7c8	7bf8e93d-4a06-4102-be6f-5e371cb5c89e	c9b66fe3-5193-4a2a-a75d-c78c9d4d961c	1	create	0ca9ad9a-40e6-45bd-9505-6f3ef1ab5212	notes/smoke.md	1	sha256:smoke-1771423042361	2026-02-18 13:57:22.531559+00
519fbf1a-5c00-43ff-a8a3-a73c95a76dec	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	8cd57ae3-876e-4d19-b198-5fe5af5322c5	1	create	cdcff7bc-b3a7-4b9c-a949-db5c34f29e94	notes/conflict.md	1	sha256:reg-e4b6c239-77e2-446a-9926-ff7246d29744	2026-02-18 14:06:26.93324+00
9db82c17-1090-4d02-8127-253e7ce2b9a6	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	156168f7-edb4-4dbc-9006-13bee8617e6b	2	update	cdcff7bc-b3a7-4b9c-a949-db5c34f29e94	notes/conflict.md	2	sha256:reg-71e9bb2c-1614-4f94-a70b-dddf485dc0da	2026-02-18 14:06:27.349387+00
6cf60141-a044-44a4-b507-0cda6ab21a5a	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	43f7fe00-681a-46ed-961b-f9fc766db7a2	3	rename	cdcff7bc-b3a7-4b9c-a949-db5c34f29e94	notes/conflict-renamed.md	3	sha256:reg-71e9bb2c-1614-4f94-a70b-dddf485dc0da	2026-02-18 14:06:27.770421+00
97f39d6e-f368-4b5d-9e59-b5f53bce7aa1	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	539470a5-870c-4f14-a400-ed7b73c3ab88	4	create	37b54015-73c0-4f2a-8085-65cd8d0d4ee9	notes/idempotency.md	1	sha256:reg-0af1b96a-de1f-4741-9a96-84750c17fd97	2026-02-18 14:06:28.144183+00
182978c8-8cf4-45ef-8453-3fe833e35f3c	63d7c318-ac3f-4a5c-9dba-4176afbcefab	745d4d4d-334b-4e3d-a87d-3298f74d4e3b	1	create	020cc64f-28ce-4fd1-86de-d6dcda3cd273	notes/smoke.md	1	sha256:smoke-1771429380336	2026-02-18 15:43:00.537738+00
a6a6e169-d883-49ca-83b5-47ce661348e4	cf617b76-948e-4687-81b2-bf5a561c1752	ab2484cf-fd37-416e-89df-fe18a683e7e7	1	create	a7889ca6-1bc3-4023-80c0-7d0496591242	notes/conflict.md	1	sha256:reg-1b242c0f-5df3-4cdc-84d0-98b5ee3b33f9	2026-02-18 15:43:05.910528+00
7b82745b-86da-4a2b-94bf-e4f0ce5726e2	cf617b76-948e-4687-81b2-bf5a561c1752	791b34fd-0918-470f-9568-d824cd0cbba1	2	update	a7889ca6-1bc3-4023-80c0-7d0496591242	notes/conflict.md	2	sha256:reg-8e0f1ac1-26cd-4802-90fc-63f34ce4dcca	2026-02-18 15:43:06.314543+00
35db7436-cf5d-4455-a8ac-69323958e7d8	cf617b76-948e-4687-81b2-bf5a561c1752	86095184-18c5-4cd5-b034-d26b314f0eba	3	rename	a7889ca6-1bc3-4023-80c0-7d0496591242	notes/conflict-renamed.md	3	sha256:reg-8e0f1ac1-26cd-4802-90fc-63f34ce4dcca	2026-02-18 15:43:06.802324+00
2c0c84cc-f799-4f97-8d82-306484afed74	cf617b76-948e-4687-81b2-bf5a561c1752	1ffab8a2-d4c4-41fa-8f1e-9fa3431af6e4	4	create	a435fe7d-6d1c-4767-b0b9-0b14781a46ec	notes/idempotency.md	1	sha256:reg-e78849da-db97-44a0-a663-543b4a894920	2026-02-18 15:43:07.196748+00
84fc0dee-4ee9-4fba-8d38-bf30fb41dff5	d94bb19b-5c7b-4212-81a1-ce95046c1d5f	9a5b7520-5760-419a-83fe-9548f4cc8e90	1	create	3180d758-0145-4232-b748-a5625aa72d85	drill/20260218T155105Z-7981632a.md	1	sha256:drill-7661935d-6797-4a72-9ad2-1b4e94680c76	2026-02-18 15:51:05.558147+00
\.


--
-- Data for Name: changesets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.changesets (id, vault_id, device_id, checkpoint, status, created_at) FROM stdin;
f9f02d5d-d314-4fea-b842-e8645e90a2df	92fe0015-2cb8-43f6-b836-a5d982ae692f	a46b0389-f6ab-4454-b7cf-c681f101bd06	1	committed	2026-02-18 13:23:15.358933+00
f314a855-e81a-4d3f-93e2-2536dc4ed49b	7f62237f-1b4c-4008-84d3-241ee11a25fc	a46b0389-f6ab-4454-b7cf-c681f101bd06	1	committed	2026-02-18 13:25:49.873056+00
cf1d7d63-d365-4c35-a547-36f927454d5f	3d84e540-449f-4818-933e-635f024a8cea	a46b0389-f6ab-4454-b7cf-c681f101bd06	1	committed	2026-02-18 13:32:44.506913+00
9bb165de-a270-4e4e-b7ac-66e797230bd4	bf005287-dca4-4685-8ac2-22185865980d	a46b0389-f6ab-4454-b7cf-c681f101bd06	1	committed	2026-02-18 13:54:31.202399+00
c9b66fe3-5193-4a2a-a75d-c78c9d4d961c	7bf8e93d-4a06-4102-be6f-5e371cb5c89e	a46b0389-f6ab-4454-b7cf-c681f101bd06	1	committed	2026-02-18 13:57:22.531559+00
8cd57ae3-876e-4d19-b198-5fe5af5322c5	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	1	committed	2026-02-18 14:06:26.93324+00
156168f7-edb4-4dbc-9006-13bee8617e6b	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	8596ed38-6306-4a74-8919-4f17d1ade5c6	2	committed	2026-02-18 14:06:27.349387+00
43f7fe00-681a-46ed-961b-f9fc766db7a2	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	8596ed38-6306-4a74-8919-4f17d1ade5c6	3	committed	2026-02-18 14:06:27.770421+00
539470a5-870c-4f14-a400-ed7b73c3ab88	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	4	committed	2026-02-18 14:06:28.144183+00
745d4d4d-334b-4e3d-a87d-3298f74d4e3b	63d7c318-ac3f-4a5c-9dba-4176afbcefab	a46b0389-f6ab-4454-b7cf-c681f101bd06	1	committed	2026-02-18 15:43:00.537738+00
ab2484cf-fd37-416e-89df-fe18a683e7e7	cf617b76-948e-4687-81b2-bf5a561c1752	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	1	committed	2026-02-18 15:43:05.910528+00
791b34fd-0918-470f-9568-d824cd0cbba1	cf617b76-948e-4687-81b2-bf5a561c1752	8596ed38-6306-4a74-8919-4f17d1ade5c6	2	committed	2026-02-18 15:43:06.314543+00
86095184-18c5-4cd5-b034-d26b314f0eba	cf617b76-948e-4687-81b2-bf5a561c1752	8596ed38-6306-4a74-8919-4f17d1ade5c6	3	committed	2026-02-18 15:43:06.802324+00
1ffab8a2-d4c4-41fa-8f1e-9fa3431af6e4	cf617b76-948e-4687-81b2-bf5a561c1752	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	4	committed	2026-02-18 15:43:07.196748+00
9a5b7520-5760-419a-83fe-9548f4cc8e90	d94bb19b-5c7b-4212-81a1-ce95046c1d5f	ff193eee-2196-4534-a77e-4da20622a3c2	1	committed	2026-02-18 15:51:05.558147+00
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.devices (id, user_id, device_name, platform, plugin_version, status, created_at, revoked_at) FROM stdin;
a46b0389-f6ab-4454-b7cf-c681f101bd06	257eb06d-46a8-4367-82ae-bcce8a33b9a8	smoke-mac	macos	0.1.0	active	2026-02-18 13:23:14.971778+00	\N
fec8ba27-7e23-40d8-bd3f-1068f20be1f1	257eb06d-46a8-4367-82ae-bcce8a33b9a8	reg-device-a	macos	0.1.0	active	2026-02-18 14:06:26.395329+00	\N
8596ed38-6306-4a74-8919-4f17d1ade5c6	257eb06d-46a8-4367-82ae-bcce8a33b9a8	reg-device-b	android	0.1.0	active	2026-02-18 14:06:26.482558+00	\N
ff193eee-2196-4534-a77e-4da20622a3c2	257eb06d-46a8-4367-82ae-bcce8a33b9a8	drill-runner	macos	0.1.0	active	2026-02-18 15:51:05.180422+00	\N
\.


--
-- Data for Name: file_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_entries (id, vault_id, current_path, head_version, deleted_at, created_at) FROM stdin;
61c09010-627a-4b5b-a0a2-dea0f6ef678b	92fe0015-2cb8-43f6-b836-a5d982ae692f	notes/smoke.md	1	\N	2026-02-18 13:23:15.358933+00
28c4158e-3f21-444d-a916-0918f424a44b	7f62237f-1b4c-4008-84d3-241ee11a25fc	notes/smoke.md	1	\N	2026-02-18 13:25:49.873056+00
be5f4339-314d-4d71-9231-42cd931bf920	3d84e540-449f-4818-933e-635f024a8cea	notes/smoke.md	1	\N	2026-02-18 13:32:44.506913+00
0f8c2008-5fba-4866-8a2f-49670d4d47b3	bf005287-dca4-4685-8ac2-22185865980d	notes/smoke.md	1	\N	2026-02-18 13:54:31.202399+00
0ca9ad9a-40e6-45bd-9505-6f3ef1ab5212	7bf8e93d-4a06-4102-be6f-5e371cb5c89e	notes/smoke.md	1	\N	2026-02-18 13:57:22.531559+00
cdcff7bc-b3a7-4b9c-a949-db5c34f29e94	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	notes/conflict-renamed.md	3	\N	2026-02-18 14:06:26.93324+00
37b54015-73c0-4f2a-8085-65cd8d0d4ee9	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	notes/idempotency.md	1	\N	2026-02-18 14:06:28.144183+00
020cc64f-28ce-4fd1-86de-d6dcda3cd273	63d7c318-ac3f-4a5c-9dba-4176afbcefab	notes/smoke.md	1	\N	2026-02-18 15:43:00.537738+00
a7889ca6-1bc3-4023-80c0-7d0496591242	cf617b76-948e-4687-81b2-bf5a561c1752	notes/conflict-renamed.md	3	\N	2026-02-18 15:43:05.910528+00
a435fe7d-6d1c-4767-b0b9-0b14781a46ec	cf617b76-948e-4687-81b2-bf5a561c1752	notes/idempotency.md	1	\N	2026-02-18 15:43:07.196748+00
3180d758-0145-4232-b748-a5625aa72d85	d94bb19b-5c7b-4212-81a1-ce95046c1d5f	drill/20260218T155105Z-7981632a.md	1	\N	2026-02-18 15:51:05.558147+00
\.


--
-- Data for Name: file_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_versions (id, file_id, version, content_hash, author_device_id, created_at) FROM stdin;
448579be-3cde-4ff0-8dc4-dd197b936f76	61c09010-627a-4b5b-a0a2-dea0f6ef678b	1	sha256:smoke-1771420995186	a46b0389-f6ab-4454-b7cf-c681f101bd06	2026-02-18 13:23:15.358933+00
d42d285d-57ba-4e6d-ac91-d4d6803908a5	28c4158e-3f21-444d-a916-0918f424a44b	1	sha256:smoke-1771421149698	a46b0389-f6ab-4454-b7cf-c681f101bd06	2026-02-18 13:25:49.873056+00
43ca1999-f20a-444c-b2a4-06c0a589e4bd	be5f4339-314d-4d71-9231-42cd931bf920	1	sha256:smoke-1771421564345	a46b0389-f6ab-4454-b7cf-c681f101bd06	2026-02-18 13:32:44.506913+00
770039ad-47b9-4902-96f9-c6c436ed7e46	0f8c2008-5fba-4866-8a2f-49670d4d47b3	1	sha256:smoke-1771422871028	a46b0389-f6ab-4454-b7cf-c681f101bd06	2026-02-18 13:54:31.202399+00
4ac53b2b-b15e-4991-9930-cb47e5a0f32c	0ca9ad9a-40e6-45bd-9505-6f3ef1ab5212	1	sha256:smoke-1771423042361	a46b0389-f6ab-4454-b7cf-c681f101bd06	2026-02-18 13:57:22.531559+00
5b76672d-c9a2-43de-b685-1715b3793970	cdcff7bc-b3a7-4b9c-a949-db5c34f29e94	1	sha256:reg-e4b6c239-77e2-446a-9926-ff7246d29744	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	2026-02-18 14:06:26.93324+00
0533a636-3623-451c-b997-4285696b74bf	cdcff7bc-b3a7-4b9c-a949-db5c34f29e94	2	sha256:reg-71e9bb2c-1614-4f94-a70b-dddf485dc0da	8596ed38-6306-4a74-8919-4f17d1ade5c6	2026-02-18 14:06:27.349387+00
63899cfd-2405-42ec-a9b3-2b80b35c9e0d	cdcff7bc-b3a7-4b9c-a949-db5c34f29e94	3	sha256:reg-71e9bb2c-1614-4f94-a70b-dddf485dc0da	8596ed38-6306-4a74-8919-4f17d1ade5c6	2026-02-18 14:06:27.770421+00
2d45ddc3-dae4-4be9-9652-465509601584	37b54015-73c0-4f2a-8085-65cd8d0d4ee9	1	sha256:reg-0af1b96a-de1f-4741-9a96-84750c17fd97	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	2026-02-18 14:06:28.144183+00
12f3f54b-02f7-4fbf-a383-c8d78fe7de26	020cc64f-28ce-4fd1-86de-d6dcda3cd273	1	sha256:smoke-1771429380336	a46b0389-f6ab-4454-b7cf-c681f101bd06	2026-02-18 15:43:00.537738+00
9d90d272-ba0f-4bb6-b6e9-d8aa34d96c77	a7889ca6-1bc3-4023-80c0-7d0496591242	1	sha256:reg-1b242c0f-5df3-4cdc-84d0-98b5ee3b33f9	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	2026-02-18 15:43:05.910528+00
c915c056-1f39-4da1-a0c1-e622d1163e2c	a7889ca6-1bc3-4023-80c0-7d0496591242	2	sha256:reg-8e0f1ac1-26cd-4802-90fc-63f34ce4dcca	8596ed38-6306-4a74-8919-4f17d1ade5c6	2026-02-18 15:43:06.314543+00
6c4cfd92-47f0-466d-8a11-506a9925b5c7	a7889ca6-1bc3-4023-80c0-7d0496591242	3	sha256:reg-8e0f1ac1-26cd-4802-90fc-63f34ce4dcca	8596ed38-6306-4a74-8919-4f17d1ade5c6	2026-02-18 15:43:06.802324+00
6e601ebf-074b-4272-aa29-2e70b80e0c80	a435fe7d-6d1c-4767-b0b9-0b14781a46ec	1	sha256:reg-e78849da-db97-44a0-a663-543b4a894920	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	2026-02-18 15:43:07.196748+00
eef2e1ba-1eb3-4818-8035-521e2c6e5b63	3180d758-0145-4232-b748-a5625aa72d85	1	sha256:drill-7661935d-6797-4a72-9ad2-1b4e94680c76	ff193eee-2196-4534-a77e-4da20622a3c2	2026-02-18 15:51:05.558147+00
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.idempotency_keys (id, vault_id, idempotency_key, response_json, created_at) FROM stdin;
6fdc6a3a-6a42-40e0-9f4a-059c1d9635dd	92fe0015-2cb8-43f6-b836-a5d982ae692f	299a1e6d-a28a-4fa2-94ba-a34791087ff3	{"changesetId": "f9f02d5d-d314-4fea-b842-e8645e90a2df", "newCheckpoint": "cp_1", "appliedChanges": 1}	2026-02-18 13:23:15.358933+00
0190fe2f-9684-4be8-8b3e-ea5a7dc08a7f	7f62237f-1b4c-4008-84d3-241ee11a25fc	f9f9bc67-6b43-4b45-9078-1198b4a2031c	{"changesetId": "f314a855-e81a-4d3f-93e2-2536dc4ed49b", "newCheckpoint": "cp_1", "appliedChanges": 1}	2026-02-18 13:25:49.873056+00
e00dda00-cb2d-47bc-b822-9beb16aa30be	3d84e540-449f-4818-933e-635f024a8cea	4615f26a-085b-4b71-8224-1208a6fc5d4a	{"changesetId": "cf1d7d63-d365-4c35-a547-36f927454d5f", "newCheckpoint": "cp_1", "appliedChanges": 1}	2026-02-18 13:32:44.506913+00
6b0e81fa-ccc4-4ba4-9df9-a2a7dec53e5b	bf005287-dca4-4685-8ac2-22185865980d	89e0636f-2f58-4999-97c0-451aebaffb0f	{"changesetId": "9bb165de-a270-4e4e-b7ac-66e797230bd4", "newCheckpoint": "cp_1", "appliedChanges": 1}	2026-02-18 13:54:31.202399+00
0eb7a2e4-a96f-4bc8-92b6-6055e240e58e	7bf8e93d-4a06-4102-be6f-5e371cb5c89e	f6234585-d025-477d-8ac5-975a68a8e8c2	{"changesetId": "c9b66fe3-5193-4a2a-a75d-c78c9d4d961c", "newCheckpoint": "cp_1", "appliedChanges": 1}	2026-02-18 13:57:22.531559+00
922c2214-6838-4fc8-a5de-617e7c14fb17	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	9fd105d5-67b5-4ba5-8e11-fa929d768630	{"changesetId": "8cd57ae3-876e-4d19-b198-5fe5af5322c5", "newCheckpoint": "cp_1", "appliedChanges": 1}	2026-02-18 14:06:26.93324+00
88e74ece-e762-40ce-931c-b89ecc81e6ae	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	1c82750f-ddbc-4e5f-84ea-1761ee956bc7	{"changesetId": "156168f7-edb4-4dbc-9006-13bee8617e6b", "newCheckpoint": "cp_2", "appliedChanges": 1}	2026-02-18 14:06:27.349387+00
02c14524-4da1-49ee-a575-82ca37bbfc1c	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	d4657948-f20e-44df-a7bc-41e2e98b9dd2	{"changesetId": "43f7fe00-681a-46ed-961b-f9fc766db7a2", "newCheckpoint": "cp_3", "appliedChanges": 1}	2026-02-18 14:06:27.770421+00
f7ce88f4-7c9d-42e6-9e11-d7eef02fe7ed	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	4e7d5676-41d2-4f21-a8bb-f96ee850f39e	{"changesetId": "539470a5-870c-4f14-a400-ed7b73c3ab88", "newCheckpoint": "cp_4", "appliedChanges": 1}	2026-02-18 14:06:28.144183+00
bd701fc4-3129-494d-b201-cda022d3c1b9	63d7c318-ac3f-4a5c-9dba-4176afbcefab	3c8fa021-9ef2-4f1f-8b95-610737bc9fab	{"changesetId": "745d4d4d-334b-4e3d-a87d-3298f74d4e3b", "newCheckpoint": "cp_1", "appliedChanges": 1}	2026-02-18 15:43:00.537738+00
faa4e544-e572-4f57-8a67-36c4557613cd	cf617b76-948e-4687-81b2-bf5a561c1752	86658327-8275-4d6a-9d39-b1150bd257d9	{"changesetId": "ab2484cf-fd37-416e-89df-fe18a683e7e7", "newCheckpoint": "cp_1", "appliedChanges": 1}	2026-02-18 15:43:05.910528+00
5629172a-8a40-4e64-a0b5-75d70ada3294	cf617b76-948e-4687-81b2-bf5a561c1752	3823296a-c5b5-433a-ac33-ed39aef572ae	{"changesetId": "791b34fd-0918-470f-9568-d824cd0cbba1", "newCheckpoint": "cp_2", "appliedChanges": 1}	2026-02-18 15:43:06.314543+00
f8b2fccc-89c1-4de4-9940-edb824bd62e0	cf617b76-948e-4687-81b2-bf5a561c1752	c0e21fa2-e617-4778-86c8-a387252abf4c	{"changesetId": "86095184-18c5-4cd5-b034-d26b314f0eba", "newCheckpoint": "cp_3", "appliedChanges": 1}	2026-02-18 15:43:06.802324+00
0be1356e-816a-4976-af7c-b6ad022030cc	cf617b76-948e-4687-81b2-bf5a561c1752	c7ee9dcd-8a97-4fba-a0ff-6065cae35df3	{"changesetId": "1ffab8a2-d4c4-41fa-8f1e-9fa3431af6e4", "newCheckpoint": "cp_4", "appliedChanges": 1}	2026-02-18 15:43:07.196748+00
89642613-d5cc-4996-a83e-108b7ae2d413	d94bb19b-5c7b-4212-81a1-ce95046c1d5f	ea95cb01-dcb6-47c7-bfb9-948d80690b45	{"changesetId": "9a5b7520-5760-419a-83fe-9548f4cc8e90", "newCheckpoint": "cp_1", "appliedChanges": 1}	2026-02-18 15:51:05.558147+00
\.


--
-- Data for Name: object_blobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.object_blobs (content_hash, size_bytes, created_at) FROM stdin;
sha256:smoke-1771420995186	\N	2026-02-18 13:23:15.358933+00
sha256:smoke-1771421149698	\N	2026-02-18 13:25:49.873056+00
sha256:smoke-1771421564345	\N	2026-02-18 13:32:44.506913+00
sha256:smoke-1771422871028	\N	2026-02-18 13:54:31.202399+00
sha256:smoke-1771423042361	\N	2026-02-18 13:57:22.531559+00
sha256:reg-e4b6c239-77e2-446a-9926-ff7246d29744	\N	2026-02-18 14:06:26.93324+00
sha256:reg-71e9bb2c-1614-4f94-a70b-dddf485dc0da	\N	2026-02-18 14:06:27.349387+00
sha256:reg-0af1b96a-de1f-4741-9a96-84750c17fd97	\N	2026-02-18 14:06:28.144183+00
sha256:smoke-1771429380336	\N	2026-02-18 15:43:00.537738+00
sha256:reg-1b242c0f-5df3-4cdc-84d0-98b5ee3b33f9	\N	2026-02-18 15:43:05.910528+00
sha256:reg-8e0f1ac1-26cd-4802-90fc-63f34ce4dcca	\N	2026-02-18 15:43:06.314543+00
sha256:reg-e78849da-db97-44a0-a663-543b4a894920	\N	2026-02-18 15:43:07.196748+00
sha256:drill-7661935d-6797-4a72-9ad2-1b4e94680c76	\N	2026-02-18 15:51:05.558147+00
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_tokens (id, user_id, device_id, token_hash, expires_at, created_at, revoked_at) FROM stdin;
480c0b54-7424-4462-b33a-abf730467c24	257eb06d-46a8-4367-82ae-bcce8a33b9a8	a46b0389-f6ab-4454-b7cf-c681f101bd06	ee0bb714f3b9692ff5ee8936dac093b98c7e66652b8baf6fca2326952ace27bd	2026-03-20 13:23:14.978+00	2026-02-18 13:23:14.977176+00	\N
b2b8c18b-cf57-4454-b79e-95a0cdb0c138	257eb06d-46a8-4367-82ae-bcce8a33b9a8	a46b0389-f6ab-4454-b7cf-c681f101bd06	a5bfcc7abb517b83917e689249437dfda0335490979fc1f1d7a087c6a696a321	2026-03-20 13:25:49.51+00	2026-02-18 13:25:49.509577+00	\N
25651b55-4463-4fca-a2a4-c4aa31c68552	257eb06d-46a8-4367-82ae-bcce8a33b9a8	a46b0389-f6ab-4454-b7cf-c681f101bd06	9c51fcab5df0134f7cd7c0f5a29ed15967338f0bddee5805d501269a736ce523	2026-03-20 13:32:44.165+00	2026-02-18 13:32:44.165368+00	\N
4f5ac4c6-385e-4779-9372-1c321946e0bc	257eb06d-46a8-4367-82ae-bcce8a33b9a8	a46b0389-f6ab-4454-b7cf-c681f101bd06	bf67f015e622a38bc38b66668367e1d227fe1a81c98a3e0de3bdcc7018b21c02	2026-03-20 13:54:30.814+00	2026-02-18 13:54:30.814359+00	\N
3dcff0dc-bafe-4333-9672-ccc11c44159e	257eb06d-46a8-4367-82ae-bcce8a33b9a8	a46b0389-f6ab-4454-b7cf-c681f101bd06	be33c421807172bbd38ed37af442d4ffe99d917582dc2e8a6c23bdea0964c739	2026-03-20 13:57:22.18+00	2026-02-18 13:57:22.180246+00	\N
0fe6887a-2ff4-489e-a61e-ec4f58dcd6d7	257eb06d-46a8-4367-82ae-bcce8a33b9a8	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	0eeb6f7bae5550864815651d0d53debe17da56fa150a0032c5ffcb4de3be068c	2026-03-20 14:06:26.401+00	2026-02-18 14:06:26.400257+00	\N
703e3bd1-3173-4d86-9196-c9f18ea10031	257eb06d-46a8-4367-82ae-bcce8a33b9a8	8596ed38-6306-4a74-8919-4f17d1ade5c6	5b8088104a9e4222f1ec213d460984904993b58cf1ef789fb395400bbac1693d	2026-03-20 14:06:26.486+00	2026-02-18 14:06:26.484583+00	\N
ffcb6e2a-0b32-4e1d-945d-9853e14e173f	257eb06d-46a8-4367-82ae-bcce8a33b9a8	a46b0389-f6ab-4454-b7cf-c681f101bd06	d312bd3d50812a5c084c3e12b63b3f430f5d73cf95e4b7305f2196238181b904	2026-03-20 15:43:00.155+00	2026-02-18 15:43:00.154541+00	\N
c7f27262-429b-4c2a-80a5-b31a8b48d806	257eb06d-46a8-4367-82ae-bcce8a33b9a8	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	a6a1f19aacbc7520c2dcfc914318816ffb519b3715c49a1b709d8c0587b28fe3	2026-03-20 15:43:05.42+00	2026-02-18 15:43:05.420056+00	\N
5b01a55c-12e5-4bfc-b477-587e60013e44	257eb06d-46a8-4367-82ae-bcce8a33b9a8	8596ed38-6306-4a74-8919-4f17d1ade5c6	b0f992d347237a1cff4d5bd2e4d60105b70920b2db3f06c5398700dce4283d0c	2026-03-20 15:43:05.501+00	2026-02-18 15:43:05.500129+00	\N
24d92c24-d196-4085-9190-6ee5d145edc1	257eb06d-46a8-4367-82ae-bcce8a33b9a8	ff193eee-2196-4534-a77e-4da20622a3c2	d00e813a800d3aabe0b9d54b4bc2d94c2c6e5592aa6c2c55ed89cff9a0ca0dbc	2026-03-20 15:51:05.187+00	2026-02-18 15:51:05.186271+00	\N
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (id, applied_at) FROM stdin;
001_init.sql	2026-02-18 13:21:17.982277+00
002_sync_prepare_and_events.sql	2026-02-18 13:21:18.003561+00
\.


--
-- Data for Name: sync_prepares; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sync_prepares (id, vault_id, device_id, base_checkpoint, changes_json, conflicts_json, status, expires_at, created_at) FROM stdin;
ca5c65c9-e349-495c-b480-fd033d6aaf68	92fe0015-2cb8-43f6-b836-a5d982ae692f	a46b0389-f6ab-4454-b7cf-c681f101bd06	0	[{"op": "create", "path": "notes/smoke.md", "contentHash": "sha256:smoke-1771420995186"}]	[]	committed	2026-02-18 13:33:15.212+00	2026-02-18 13:23:15.210737+00
a7f2b8ea-702d-414c-b253-470944942e3c	7f62237f-1b4c-4008-84d3-241ee11a25fc	a46b0389-f6ab-4454-b7cf-c681f101bd06	0	[{"op": "create", "path": "notes/smoke.md", "contentHash": "sha256:smoke-1771421149698"}]	[]	committed	2026-02-18 13:35:49.724+00	2026-02-18 13:25:49.723911+00
f3e66f30-beec-4c10-a65f-436a61936ebc	3d84e540-449f-4818-933e-635f024a8cea	a46b0389-f6ab-4454-b7cf-c681f101bd06	0	[{"op": "create", "path": "notes/smoke.md", "contentHash": "sha256:smoke-1771421564345"}]	[]	committed	2026-02-18 13:42:44.368+00	2026-02-18 13:32:44.368227+00
c84ba723-46a0-4b63-8b4d-2692b2d6a6b1	bf005287-dca4-4685-8ac2-22185865980d	a46b0389-f6ab-4454-b7cf-c681f101bd06	0	[{"op": "create", "path": "notes/smoke.md", "contentHash": "sha256:smoke-1771422871028"}]	[]	committed	2026-02-18 14:04:31.053+00	2026-02-18 13:54:31.052785+00
374ae216-4753-4516-8828-bfdd5ffed4d5	7bf8e93d-4a06-4102-be6f-5e371cb5c89e	a46b0389-f6ab-4454-b7cf-c681f101bd06	0	[{"op": "create", "path": "notes/smoke.md", "contentHash": "sha256:smoke-1771423042361"}]	[]	committed	2026-02-18 14:07:22.384+00	2026-02-18 13:57:22.383572+00
bb9c84de-31a3-4fcb-b2f9-9783f56924c1	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	0	[{"op": "create", "path": "notes/conflict.md", "contentHash": "sha256:reg-e4b6c239-77e2-446a-9926-ff7246d29744"}]	[]	committed	2026-02-18 14:16:26.785+00	2026-02-18 14:06:26.783996+00
865805b1-feb3-472c-8056-744723e2f7eb	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	8596ed38-6306-4a74-8919-4f17d1ade5c6	1	[{"op": "update", "path": "notes/conflict.md", "fileId": "cdcff7bc-b3a7-4b9c-a949-db5c34f29e94", "baseVersion": 1, "contentHash": "sha256:reg-71e9bb2c-1614-4f94-a70b-dddf485dc0da"}]	[]	committed	2026-02-18 14:16:27.207+00	2026-02-18 14:06:27.206018+00
b831fab6-a1ac-4cc1-a543-fa94098e3cd9	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	2	[{"op": "update", "path": "notes/conflict.md", "fileId": "cdcff7bc-b3a7-4b9c-a949-db5c34f29e94", "baseVersion": 1, "contentHash": "sha256:reg-5692aad8-65b9-4f8c-8000-27a45d77cf31"}]	[{"code": "VERSION_CONFLICT", "path": "notes/conflict.md", "index": 0, "fileId": "cdcff7bc-b3a7-4b9c-a949-db5c34f29e94", "message": "baseVersion 1 does not match headVersion 2"}]	conflicted	2026-02-18 14:16:27.585+00	2026-02-18 14:06:27.583771+00
dfe88d7c-6ae8-4c7c-aab3-b9492f15b42c	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	8596ed38-6306-4a74-8919-4f17d1ade5c6	2	[{"op": "rename", "path": "notes/conflict-renamed.md", "fileId": "cdcff7bc-b3a7-4b9c-a949-db5c34f29e94", "baseVersion": 2}]	[]	committed	2026-02-18 14:16:27.67+00	2026-02-18 14:06:27.668534+00
cf98f817-18c8-4bc1-8f38-ed7c34f8eaf4	8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	3	[{"op": "create", "path": "notes/idempotency.md", "contentHash": "sha256:reg-0af1b96a-de1f-4741-9a96-84750c17fd97"}]	[]	committed	2026-02-18 14:16:28+00	2026-02-18 14:06:27.999025+00
2f719a13-450f-43e0-92cc-3f96e458fa10	63d7c318-ac3f-4a5c-9dba-4176afbcefab	a46b0389-f6ab-4454-b7cf-c681f101bd06	0	[{"op": "create", "path": "notes/smoke.md", "contentHash": "sha256:smoke-1771429380336"}]	[]	committed	2026-02-18 15:53:00.362+00	2026-02-18 15:43:00.362225+00
08f67c90-704e-403a-8b2a-0d88645da297	cf617b76-948e-4687-81b2-bf5a561c1752	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	0	[{"op": "create", "path": "notes/conflict.md", "contentHash": "sha256:reg-1b242c0f-5df3-4cdc-84d0-98b5ee3b33f9"}]	[]	committed	2026-02-18 15:53:05.771+00	2026-02-18 15:43:05.770807+00
5e4d4e5a-0449-42dd-a089-2d6b4f6775e8	cf617b76-948e-4687-81b2-bf5a561c1752	8596ed38-6306-4a74-8919-4f17d1ade5c6	1	[{"op": "update", "path": "notes/conflict.md", "fileId": "a7889ca6-1bc3-4023-80c0-7d0496591242", "baseVersion": 1, "contentHash": "sha256:reg-8e0f1ac1-26cd-4802-90fc-63f34ce4dcca"}]	[]	committed	2026-02-18 15:53:06.175+00	2026-02-18 15:43:06.17482+00
f05a7e3c-bd9c-4938-9811-9b1b77158464	cf617b76-948e-4687-81b2-bf5a561c1752	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	2	[{"op": "update", "path": "notes/conflict.md", "fileId": "a7889ca6-1bc3-4023-80c0-7d0496591242", "baseVersion": 1, "contentHash": "sha256:reg-186095de-5e5d-45c7-a3d5-5a223f0ab7e2"}]	[{"code": "VERSION_CONFLICT", "path": "notes/conflict.md", "index": 0, "fileId": "a7889ca6-1bc3-4023-80c0-7d0496591242", "message": "baseVersion 1 does not match headVersion 2"}]	conflicted	2026-02-18 15:53:06.597+00	2026-02-18 15:43:06.596745+00
10d26543-cc07-4ece-8f17-701354e13306	cf617b76-948e-4687-81b2-bf5a561c1752	8596ed38-6306-4a74-8919-4f17d1ade5c6	2	[{"op": "rename", "path": "notes/conflict-renamed.md", "fileId": "a7889ca6-1bc3-4023-80c0-7d0496591242", "baseVersion": 2}]	[]	committed	2026-02-18 15:53:06.711+00	2026-02-18 15:43:06.710343+00
980c9452-f01a-4671-b5bc-60aae04e56e3	cf617b76-948e-4687-81b2-bf5a561c1752	fec8ba27-7e23-40d8-bd3f-1068f20be1f1	3	[{"op": "create", "path": "notes/idempotency.md", "contentHash": "sha256:reg-e78849da-db97-44a0-a663-543b4a894920"}]	[]	committed	2026-02-18 15:53:07.033+00	2026-02-18 15:43:07.032851+00
cd4f3030-bada-4653-b8e2-941f689d72c1	d94bb19b-5c7b-4212-81a1-ce95046c1d5f	ff193eee-2196-4534-a77e-4da20622a3c2	0	[{"op": "create", "path": "drill/20260218T155105Z-7981632a.md", "contentHash": "sha256:drill-7661935d-6797-4a72-9ad2-1b4e94680c76"}]	[]	committed	2026-02-18 16:01:05.416+00	2026-02-18 15:51:05.416902+00
\.


--
-- Data for Name: tombstones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tombstones (id, vault_id, file_id, deleted_at, expire_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, created_at) FROM stdin;
257eb06d-46a8-4367-82ae-bcce8a33b9a8	admin@example.com	fec7ca8e18259173a02369af9d542525:cfb3ccba6e3af60ec52abcac0580a97d24e37000fe804e12509b4754a7cb9c40eb2b310688d533dfe5ff9a59ebc11a9988bc54f856ecafe49e01f8b122ed7587	2026-02-18 13:21:18.04015+00
\.


--
-- Data for Name: vault_sync_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vault_sync_state (vault_id, latest_checkpoint, updated_at) FROM stdin;
92fe0015-2cb8-43f6-b836-a5d982ae692f	1	2026-02-18 13:23:15.358933+00
7f62237f-1b4c-4008-84d3-241ee11a25fc	1	2026-02-18 13:25:49.873056+00
3d84e540-449f-4818-933e-635f024a8cea	1	2026-02-18 13:32:44.506913+00
bf005287-dca4-4685-8ac2-22185865980d	1	2026-02-18 13:54:31.202399+00
7bf8e93d-4a06-4102-be6f-5e371cb5c89e	1	2026-02-18 13:57:22.531559+00
8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	4	2026-02-18 14:06:28.144183+00
63d7c318-ac3f-4a5c-9dba-4176afbcefab	1	2026-02-18 15:43:00.537738+00
cf617b76-948e-4687-81b2-bf5a561c1752	4	2026-02-18 15:43:07.196748+00
d94bb19b-5c7b-4212-81a1-ce95046c1d5f	1	2026-02-18 15:51:05.558147+00
\.


--
-- Data for Name: vaults; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vaults (id, owner_user_id, name, created_at) FROM stdin;
92fe0015-2cb8-43f6-b836-a5d982ae692f	257eb06d-46a8-4367-82ae-bcce8a33b9a8	SmokeVault	2026-02-18 13:23:15.050075+00
7f62237f-1b4c-4008-84d3-241ee11a25fc	257eb06d-46a8-4367-82ae-bcce8a33b9a8	SmokeVault	2026-02-18 13:25:49.564541+00
3d84e540-449f-4818-933e-635f024a8cea	257eb06d-46a8-4367-82ae-bcce8a33b9a8	SmokeVault	2026-02-18 13:32:44.215355+00
bf005287-dca4-4685-8ac2-22185865980d	257eb06d-46a8-4367-82ae-bcce8a33b9a8	SmokeVault	2026-02-18 13:54:30.885862+00
7bf8e93d-4a06-4102-be6f-5e371cb5c89e	257eb06d-46a8-4367-82ae-bcce8a33b9a8	SmokeVault	2026-02-18 13:57:22.23566+00
8f31d1bd-7e6b-4cd4-8dd6-f77719b03288	257eb06d-46a8-4367-82ae-bcce8a33b9a8	RegressionVault-1771423586	2026-02-18 14:06:26.544629+00
63d7c318-ac3f-4a5c-9dba-4176afbcefab	257eb06d-46a8-4367-82ae-bcce8a33b9a8	SmokeVault	2026-02-18 15:43:00.208873+00
cf617b76-948e-4687-81b2-bf5a561c1752	257eb06d-46a8-4367-82ae-bcce8a33b9a8	RegressionVault-1771429385	2026-02-18 15:43:05.550056+00
d94bb19b-5c7b-4212-81a1-ce95046c1d5f	257eb06d-46a8-4367-82ae-bcce8a33b9a8	DrillVault-20260218T155105Z-7981632a	2026-02-18 15:51:05.234124+00
\.


--
-- Name: change_events change_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change_events
    ADD CONSTRAINT change_events_pkey PRIMARY KEY (id);


--
-- Name: changesets changesets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.changesets
    ADD CONSTRAINT changesets_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: devices devices_user_id_device_name_platform_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_user_id_device_name_platform_key UNIQUE (user_id, device_name, platform);


--
-- Name: file_entries file_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_entries
    ADD CONSTRAINT file_entries_pkey PRIMARY KEY (id);


--
-- Name: file_versions file_versions_file_id_version_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_versions
    ADD CONSTRAINT file_versions_file_id_version_key UNIQUE (file_id, version);


--
-- Name: file_versions file_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_versions
    ADD CONSTRAINT file_versions_pkey PRIMARY KEY (id);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (id);


--
-- Name: idempotency_keys idempotency_keys_vault_id_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_vault_id_idempotency_key_key UNIQUE (vault_id, idempotency_key);


--
-- Name: object_blobs object_blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.object_blobs
    ADD CONSTRAINT object_blobs_pkey PRIMARY KEY (content_hash);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: sync_prepares sync_prepares_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sync_prepares
    ADD CONSTRAINT sync_prepares_pkey PRIMARY KEY (id);


--
-- Name: tombstones tombstones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tombstones
    ADD CONSTRAINT tombstones_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vault_sync_state vault_sync_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vault_sync_state
    ADD CONSTRAINT vault_sync_state_pkey PRIMARY KEY (vault_id);


--
-- Name: vaults vaults_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vaults
    ADD CONSTRAINT vaults_pkey PRIMARY KEY (id);


--
-- Name: idx_change_events_vault_checkpoint; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_change_events_vault_checkpoint ON public.change_events USING btree (vault_id, checkpoint);


--
-- Name: idx_changesets_vault_checkpoint; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_changesets_vault_checkpoint ON public.changesets USING btree (vault_id, checkpoint);


--
-- Name: idx_devices_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_devices_user_id ON public.devices USING btree (user_id);


--
-- Name: idx_file_entries_vault_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_file_entries_vault_id ON public.file_entries USING btree (vault_id);


--
-- Name: idx_file_entries_vault_path_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_file_entries_vault_path_active ON public.file_entries USING btree (vault_id, current_path) WHERE (deleted_at IS NULL);


--
-- Name: idx_refresh_tokens_device; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_refresh_tokens_device ON public.refresh_tokens USING btree (device_id);


--
-- Name: idx_sync_prepares_vault_device; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sync_prepares_vault_device ON public.sync_prepares USING btree (vault_id, device_id);


--
-- Name: idx_vaults_owner_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vaults_owner_user_id ON public.vaults USING btree (owner_user_id);


--
-- Name: change_events change_events_changeset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change_events
    ADD CONSTRAINT change_events_changeset_id_fkey FOREIGN KEY (changeset_id) REFERENCES public.changesets(id) ON DELETE CASCADE;


--
-- Name: change_events change_events_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change_events
    ADD CONSTRAINT change_events_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file_entries(id) ON DELETE CASCADE;


--
-- Name: change_events change_events_vault_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.change_events
    ADD CONSTRAINT change_events_vault_id_fkey FOREIGN KEY (vault_id) REFERENCES public.vaults(id) ON DELETE CASCADE;


--
-- Name: changesets changesets_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.changesets
    ADD CONSTRAINT changesets_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: changesets changesets_vault_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.changesets
    ADD CONSTRAINT changesets_vault_id_fkey FOREIGN KEY (vault_id) REFERENCES public.vaults(id) ON DELETE CASCADE;


--
-- Name: devices devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: file_entries file_entries_vault_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_entries
    ADD CONSTRAINT file_entries_vault_id_fkey FOREIGN KEY (vault_id) REFERENCES public.vaults(id) ON DELETE CASCADE;


--
-- Name: file_versions file_versions_author_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_versions
    ADD CONSTRAINT file_versions_author_device_id_fkey FOREIGN KEY (author_device_id) REFERENCES public.devices(id);


--
-- Name: file_versions file_versions_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_versions
    ADD CONSTRAINT file_versions_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file_entries(id) ON DELETE CASCADE;


--
-- Name: idempotency_keys idempotency_keys_vault_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_vault_id_fkey FOREIGN KEY (vault_id) REFERENCES public.vaults(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sync_prepares sync_prepares_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sync_prepares
    ADD CONSTRAINT sync_prepares_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: sync_prepares sync_prepares_vault_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sync_prepares
    ADD CONSTRAINT sync_prepares_vault_id_fkey FOREIGN KEY (vault_id) REFERENCES public.vaults(id) ON DELETE CASCADE;


--
-- Name: tombstones tombstones_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tombstones
    ADD CONSTRAINT tombstones_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file_entries(id) ON DELETE CASCADE;


--
-- Name: tombstones tombstones_vault_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tombstones
    ADD CONSTRAINT tombstones_vault_id_fkey FOREIGN KEY (vault_id) REFERENCES public.vaults(id) ON DELETE CASCADE;


--
-- Name: vault_sync_state vault_sync_state_vault_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vault_sync_state
    ADD CONSTRAINT vault_sync_state_vault_id_fkey FOREIGN KEY (vault_id) REFERENCES public.vaults(id) ON DELETE CASCADE;


--
-- Name: vaults vaults_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vaults
    ADD CONSTRAINT vaults_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict De47muokqT6ekrbE0E3rxoo0qFQQNpFxiP5kNZLQlc3dqWI2kRE3GN86JLquPsn

